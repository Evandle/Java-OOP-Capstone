CREATE VIEW inventory_summary AS
SELECT
    i.item_id,
    i.name AS Item,
    i.price,
    i.quantity_in_stock AS Stock,
    c.name AS Category
FROM items i
         LEFT JOIN categories c ON i.category_id = c.category_id;

